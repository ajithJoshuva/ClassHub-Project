const { validateregister } = require('./registervalidator')


module.exports = { validateregister }